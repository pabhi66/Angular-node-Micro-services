import { IPageContent } from './page-content.interface';

export interface IPage {
  title: string;
  route: string;
  shortRoute: string;
  // *******************
  description: string;
}
