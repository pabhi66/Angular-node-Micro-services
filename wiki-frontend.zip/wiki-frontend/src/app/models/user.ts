export class User {
  uid: string;
  psw: string;
  first: string;
  last: string;
  eml: string;
  username: string;
  constructor() {}
}
