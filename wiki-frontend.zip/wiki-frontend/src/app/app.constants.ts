export const BASEURL = 'http://localhost:8080/api/v1';
export const LOGINURL = BASEURL + '/login';
export const LOGOUTURL = BASEURL + '/logout';
export const SIGNUPURL = BASEURL + '/newuser';
export const PAGESURL = BASEURL + '/pages';
export const USERSURL = BASEURL + '/users';
