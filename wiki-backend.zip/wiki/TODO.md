NOTES: 
 * ENV varaibles for hostnames and ports are a good idea
 * Use a good logging library
 * Style uniformity
 * Consistent naming and file layout
 * Proper 404s with logging when endpoints don't exist
 * Redesign user API so that we have one path for all functionality
 * Try your hardest to get a stacktrace, and then make it impossible for it to happen again
 * GET RID OF ALL MAGIC STRINGS