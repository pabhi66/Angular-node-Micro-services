const appTLD = 'www.wiki.com';
const jwtSecret = 'shhh';
const jwtAlgo = 'HS256';
const jwtExpiration = '1h';

module.exports = {
  appTLD: appTLD,
  jwtSecret: jwtSecret,
  jwtAlgo: jwtAlgo,
  jwtExpiration: jwtExpiration
};
